"""
node1 节点定义
Process user query

节点类型: llm
"""

from typing import Dict, Any
from state import AgentState


def node1(state: AgentState) -> AgentState:
    """Process user query"""
    # 节点类型: llm
    user_query = state.get("user_query")
    
    # LLM 节点逻辑
    # TODO: 实现 LLM 节点逻辑
    output = "llm result"
    state["intermediate_result"] = output
    return state
