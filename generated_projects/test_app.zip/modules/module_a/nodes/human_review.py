"""
human_review 节点定义
Human review node

节点类型: human
"""

from typing import Dict, Any
from state import AgentState


def human_review(state: AgentState) -> AgentState:
    """Human review node"""
    # 节点类型: human
    tool_result = state.get("tool_result")
    
    # 人工介入节点
    # 这里会暂停等待人工输入
    output = state.get("human_input", "")
    state["final_report"] = output
    return state
