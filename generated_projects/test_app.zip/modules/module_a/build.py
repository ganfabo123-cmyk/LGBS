"""
module_a 模块构建脚本
"""

from langgraph import StateGraph, END
from state import AgentState
from .nodes.node1 import node1
from .nodes.node2 import node2
from .nodes.human_review import human_review


def build_module_a_graph():
    """构建 module_a 模块的图"""
    workflow = StateGraph(AgentState)
    
    # 添加节点
    workflow.add_node("node1", node1)
    workflow.add_node("node2", node2)
    workflow.add_node("human_review", human_review)
    
    # 添加边
    workflow.add_conditional_edges(
        "node1",
        lambda state: "node2" if result == 'success' else END,
        {"node2": "node2", END: END}
    )
    workflow.add_edge("node2", "human_review")
    workflow.add_edge("human_review", END)
    
    # 设置入口点
    workflow.set_entry_point("node1")
    
    # 编译图
    return workflow.compile()

if __name__ == "__main__":
    # 测试运行
    graph = build_module_a_graph()
    print("module_a graph built successfully!")
