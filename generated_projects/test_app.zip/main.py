"""
Test App
A test application

初始输入: user_query
最终输出: final_report
"""

from langgraph import StateGraph, END
from state import AgentState
from modules.module_a.build import build_module_a_graph

def build_main_graph():
    """构建主图"""
    workflow = StateGraph(AgentState)
    
    # Module A
    module_a_graph = build_module_a_graph()
    workflow.add_node("module_a", module_a_graph)
    
    workflow.set_entry_point("module_a")
    workflow.add_edge("module_a", END)
    
    # 编译图
    app = workflow.compile()
    
    return app

if __name__ == "__main__":
    # 测试运行
    app = build_main_graph()
    
    # 初始状态
    initial_state = {
        "user_query": "test input",
    }
    
    # 运行
    result = app.invoke(initial_state)
    print("Result:", result)
