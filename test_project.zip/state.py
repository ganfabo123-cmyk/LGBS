from typing import TypedDict, Any, Annotated
import operator

class AgentState(TypedDict):
    """全局状态定义"""
    query: string
    results: string
