"""
Test Project
A test project for API testing

初始输入: 
最终输出: 
"""

from langgraph import StateGraph, END
from state import AgentState
from modules.information_retrieval.build import build_information_retrieval_graph

def build_main_graph():
    """构建主图"""
    workflow = StateGraph(AgentState)
    
    # Module for retrieving information
    information_retrieval_graph = build_information_retrieval_graph()
    workflow.add_node("information_retrieval", information_retrieval_graph)
    
    workflow.set_entry_point("information_retrieval")
    workflow.add_edge("information_retrieval", END)
    
    # 编译图
    app = workflow.compile()
    
    return app

if __name__ == "__main__":
    # 测试运行
    app = build_main_graph()
    
    # 初始状态
    initial_state = {
    }
    
    # 运行
    result = app.invoke(initial_state)
    print("Result:", result)
