"""
information_retrieval 模块构建脚本
"""

from langgraph import StateGraph, END
from state import AgentState
from .nodes.generate_query import generate_query
from .nodes.web_search import web_search


def build_information_retrieval_graph():
    """构建 information_retrieval 模块的图"""
    workflow = StateGraph(AgentState)
    
    # 添加节点
    workflow.add_node("generate_query", generate_query)
    workflow.add_node("web_search", web_search)
    
    # 添加边
    workflow.add_edge("generate_query", "web_search")
    
    # 设置入口点
    workflow.set_entry_point("generate_query")
    
    # 编译图
    return workflow.compile()

if __name__ == "__main__":
    # 测试运行
    graph = build_information_retrieval_graph()
    print("information_retrieval graph built successfully!")
