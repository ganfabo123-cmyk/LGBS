"""
web_search 节点定义
Search the web

节点类型: tool
"""

from typing import Dict, Any
from state import AgentState


def web_search(state: AgentState) -> AgentState:
    """Search the web"""
    # 节点类型: tool
    search_query = state.get("search_query")
    
    # 工具节点逻辑
    # TODO: 实现工具节点逻辑
    output = "tool result"
    state["results"] = output
    return state
