"""
generate_query 节点定义
Generate search query

节点类型: llm
"""

from typing import Dict, Any
from state import AgentState


def generate_query(state: AgentState) -> AgentState:
    """Generate search query"""
    # 节点类型: llm
    query = state.get("query")
    
    # LLM 节点逻辑
    # TODO: 实现 LLM 节点逻辑
    output = "llm result"
    state["search_query"] = output
    return state
