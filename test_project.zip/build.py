"""
项目构建脚本
用于验证和构建整个项目
"""

import sys
from pathlib import Path

def validate_project():
    """验证项目结构"""
    print("验证项目结构...")
    
    # 检查必要文件
    required_files = [
        "state.py",
        "main.py",
        "requirements.txt",
        "modules/information_retrieval/build.py",
    ]
    
    for file in required_files:
        if not Path(file).exists():
            print(f"错误: 缺少文件 {file}")
            return False
    
    print("项目结构验证通过!")
    return True

def build_project():
    """构建项目"""
    if not validate_project():
        sys.exit(1)
    
    print("构建项目...")
    # 这里可以添加更多的构建逻辑
    print("构建完成!")

if __name__ == "__main__":
    build_project()
